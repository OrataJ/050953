package lab02;


public abstract class Vehicle {
    int wheels,lights;

    abstract void accelerate();    
    abstract void gas();
    abstract void stop();
            
    
}
