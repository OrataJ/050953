package lab02;


public class Motorcycle {
    
}
