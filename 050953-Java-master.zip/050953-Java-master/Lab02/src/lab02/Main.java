package lab02;


public class Main extends Sedan{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Sedan s=new Sedan();
        s.testDrive();
    }
    
    public void accelerate() {
    	
    }
    
}
